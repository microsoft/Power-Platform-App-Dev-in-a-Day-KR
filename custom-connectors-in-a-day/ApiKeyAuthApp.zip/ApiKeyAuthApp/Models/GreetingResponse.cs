namespace ApiKeyAuthApp.Models
{
    public class GreetingResponse
    {
        public virtual string Message { get; set; } = string.Empty;
    }
}